                                 -- ASSIGNMENT-3 --

use module
select*from Jomato

--Tasks to be performed:

--1.Create a stored procedure to display the restaurant name, type and cuisine where the
--table booking is not zero.
Create procedure Demoprocedure
as
begin
select RestaurantName, RestaurantType, CuisinesType
from Jomato
where TableBooking != 0
end
exec Demoprocedure

--2. Create a transaction and update the cuisine type �Cafe� to �Cafeteria�. Check the result
--and rollback it.

Begin transaction
update Jomato
set CuisinesType = 'Cafeteria'
where CuisinesType = 'Cafe'

select *from jomato

Rollback Transaction

--3. Generate a row number column and find the top 5 areas with the highest rating of
--restaurants.

Select Top 5 row_number() over (order by Rating desc) as Number,
RestaurantName, RestaurantType, Rating from Jomato

--4. Use the while loop to display the 1 to 50.

Declare @counter int
set @counter = 1
while @counter <= 50
begin
print @counter
set @counter = @counter + 1
end

--5.Write a query to Create a Top rating view to store the generated top 5 highest rating of
--restaurants.

Create view TopRatingView
as
Select top 5 RestaurantName, RestaurantType, Rating
from Jomato
Order by rating desc
select*from TopRatingView

--6. Write a trigger that sends an email notification to the restaurant owner whenever a new
--record is inserted.

Create Trigger TrgInsert
on Jomato
After Insert
as 
Begin
     print('New Record Inserted')
End







