                                           --ASSIGNMENT-1 --
Create database Assign1
go
use Assign1
go

--Creation of SalesMan Table
Create table Salesman
(
SalesmanID int,
Name Varchar(255),
Commission Decimal(10,2),
City Varchar(255),
Age int
)

--Insert Values in SalesMan Table
insert into Salesman values
(101,'Joe',50,'California',17),
(102,'Simon',75,'Texas',25),
(103,'Jessie',105,'Florida',35),
(104,'Danny',100,'Texas',22),
(105,'Lia',65,'New Jersy',30)

--Creation of Customer Table
create table Customer 
(
SalesmanId int,
CustomerId int,
CustomerName varchar(255),
PurchaseAmount int,
);

--Insert Values in Customer Table
Insert into Customer values
(101,2345,'Andrew',550),
(103,1575,'Lucky',4500),
(104,2345,'Andrew',4000),
(107,3747,'Remona',2700),
(110,4004,'Julia',4545)

--Creation of Orders Table
Create Table Orders
(
OrderID int,
CustomerID int,
SalesmanID int,
Orderdate Date,
Amount money
)

--Insert values in Orders table
insert into Orders values
(5001,2345,101,'2021-07-04',550),
(5003,1234,105,'2022-02-15',1500)

select*from Salesman
select*from Customer
select*from Orders

--Tasks to be Performed:

--1. Insert a new record in Orders table.
insert into Orders values
(5005,2134,107,'2023-03-14',2500)

--2. Add Primary key constraint for SalesmanId column in Salesman table. Add default
--constraint for City column in Salesman table. Add Foreign key constraint for SalesmanId
--column in Customer table. Add not null constraint in Customer_name column for the
--Customer table.

--Add Primary key constraint for SalesmanId column in Salesman table
alter table Salesman
alter column SalesmanID int not null

alter table Salesman
add constraint pk_salesmanid primary key(salesmanid)

--Add default constraint for City column in Salesman table
alter table Salesman
add constraint df_city
default 'Los Angeles' for city

--Add Foreign key constraint for SalesmanId column in Customer table
Alter table Customer with nocheck
Add Foreign Key (SalesmanID) References Salesman(SalesmanID)

--Add not null constraint in Customer_name column for the Customer table
Alter table Customer
Alter Column CustomerName Varchar(255) not null


--3. Fetch the data where the Customer�s name is ending with either �N� also get the
--purchase amount value greater than 500.
Select CustomerName, PurchaseAmount from Customer
where CustomerName like'%N' or PurchaseAmount>500


--4. Using SET operators, retrieve the first result with unique SalesmanId values from two
--tables, and the other result containing SalesmanId without duplicates from two tables.

select SalesmanID from Salesman
union
select SalesmanID from Customer

select SalesmanID from Salesman
union all
select SalesmanID from Customer


--5. Display the below columns which has the matching data.
--Orderdate, Salesman Name, Customer Name, Commission, and City which has the
--range of Purchase Amount between 1500 to 3000.

select Orderdate, Name, CustomerName, PurchaseAmount, Commission, City from Salesman S
inner join
Customer C
on
S.SalesmanID=C.SalesmanID
inner join
Orders O
on
O.SalesmanID=C.SalesmanID
where PurchaseAmount between 500 and 1500

--6. Using right join fetch all the results from Salesman and Orders table.

select*from
Salesman right join Orders
on
Salesman.Salesmanid=Orders.Salesmanid










































