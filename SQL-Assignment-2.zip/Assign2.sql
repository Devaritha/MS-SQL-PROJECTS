                                       -- ASSIGNMENT-2 --

create database module
use module
select *from dbo.jomato

--1. Create a user-defined functions to stuff the Chicken into �Quick Bites�. Eg: �Quick
--Chicken Bites�.

Create Function ChickenStuff(@inputstring varchar(max))
Returns varchar(max)
as
begin
declare @result varchar(max) 
set @result = stuff(@inputstring,7,7,'Chicken bites') 
return @result 
end
select dbo.ChickenStuff('Quick Bites') 


--2.Use the function to display the restaurant name and cuisine type which has the
--maximum number of rating.

Create function fn_rating()
returns table
return
select RestaurantName, CuisinesType, Rating from jomato
where Rating=(select max(rating) from jomato)
select *from dbo.fn_rating()


--3. Create a Rating Status column to display the rating as �Excellent� if it has more the 4
--start rating, �Good� if it has above 3.5 and below 4 star rating, �Average� if it is above 3
--and below 3.5 and �Bad� if it is below 3 star rating.

select RestaurantName, Rating,
Case
When Rating > 4 then 'Excellent'
When Rating >= 3.5 and Rating < 4 Then 'Good'
When Rating >= 3 and Rating < 3.5 Then 'Average'
When Rating < 3 Then 'Bad'
End as Rating_Status
from Jomato


--4.Find the Ceil, floor and absolute values of the rating column and display the current date
--and separately display the year, month_name and day.

Select Rating, Ceiling(Rating) as Ceil_Value, 
Floor(Rating) as Floor_Value, Abs(Rating) as Absolute_Value,
Getdate() as Curr_Date,
DateName(Year,Getdate()) as Current_Year,
DateName(Month,Getdate()) as Current_Month,
DateName(Day,Getdate()) as Current_Day
from Jomato


--5.Display the restaurant type and total average cost using rollup.

Select RestaurantType,
Sum(AverageCost) as Total_Average_Cost
from Jomato
Where RestaurantType is not null
Group by rollup (RestaurantType)























