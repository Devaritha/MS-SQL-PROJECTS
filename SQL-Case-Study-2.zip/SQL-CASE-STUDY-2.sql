--SQL CASE STUDY - 2 FOR ASSIGNMENT

--CREATING A DATABASE
create database casestudy2
use casestudy2

--CREATING LOCATION TABLE
CREATE TABLE Location ( Location_ID INT PRIMARY KEY, City VARCHAR(20) )
    
--INSERTING RECORDS INTO LOACTION TABLE
INSERT INTO Location values
(122, 'New York' ),
(123, 'Dallas' ),
(124, 'Chicago' ),
(167, 'Boston' );

--TO VIEW RECORDS OF LOCATION TABLE
SELECT * FROM Location

----------------------------------------------------------------------------------------

--CREATING DEPARTMENT TABLE
CREATE TABLE Department ( Department_ID INT PRIMARY KEY, DeptName
VARCHAR(20),

--INSERTING RECORDS IN DEPARTMENT TABLE
DepLocation_ID INT FOREIGN KEY REFERENCES Location(Location_ID))
INSERT INTO Department values
( 10,'Accounting',122 ),
( 20,'Sales',124 ),
( 30,'Research',123 ),
( 40,'Operations',167);

--TO VIEW RECORDS OF DEPARTMENT TABLE
SELECT * FROM Department

----------------------------------------------------------------------------------------

--CREATING JOB TABLE
CREATE TABLE Job ( Job_ID INT PRIMARY KEY, Designation VARCHAR(20) )

--INSERTING RECORS IN JOB TABLE
INSERT INTO Job values
( 667,'Clerk' ),
(668,'Staff' ),
(669,'Analyst'),
(670,'Sales Person'),
(671,'Manager' ),
(672,'President');

--TO VIEW RECORDS OF DEPARTMENT TABLE
SELECT * FROM Job

----------------------------------------------------------------------------------------

--CREATING EMPLOYEE TABLE
CREATE TABLE Employee ( Employee_ID INT, Last_Name VARCHAR(20),
First_Name VARCHAR(20), Middle_Name VARCHAR(20),
EmpJob_ID INT FOREIGN KEY REFERENCES Job(Job_ID),Manager_ID INT,
Hire_Date DATE, Salary INT, Comm INT,
EmpDepartment_ID INT FOREIGN KEY REFERENCES
Department(Department_ID) )

--INSERTING RECORDS IN EMPLOYEE TABLE
INSERT INTO Employee values
(7369, 'SMITH','JOHN','Q',667, 7902,'17-Dec-84',800, NULL, 20 ),
(7499, 'ALLEN','KEVIN','J',670, 7698,'20-Feb-85',1600, 300, 30 ),
( 7505, 'DOYLE','JEAN','K',671, 7839,'4-Apr-85',2850,NULL, 30),
(7506, 'DENNIS','LYNN','S',671, 7839,'15-May-85',2750, NULL, 30 ),
(7507, 'BAKER','LESLIE','D',671, 7839,'10-Jun-85',2200, NULL, 40 ),
(7521, 'WARK','CYNTHIA','D',670, 7698,'22-Feb-85',1250, 500, 30);

--TO VIEW RECORDS OF EMPLOYEE TABLE
SELECT * FROM Employee

----------------------------------------------------------------------------------------


-------------------------------SIMPLE QUERIES-------------------------------------------
--1. LIST ALL THE EMPLOYEE DETAILS.
select * from Employee;

--2. LIST ALL THE DEPARTMENT DETAILS
SELECT * FROM Department;

--3. LIST ALL JOB DETAILS.
SELECT * FROM Job;

--4. LIST ALL THE LOCATIONS
SELECT * FROM Location;

--5.LIST OUT THE FIRSTNAME, LASTNAME, SALARY, COMMISSION FOR ALL EMPLOYEES.
SELECT
    First_Name,
    Last_Name,
    Salary,
    Comm
FROM Employee;

--6.LIST OUT EMPLOYEEID,LAST NAME, DEPARTMENT ID FOR ALL EMPLOYEES AND ALIAS EMPLOYEEID AS "ID OF THE EMPLOYEE", 
--  LAST NAME AS "NAME OF THE EMPLOYEE", DEPARTMENTID AS "DEP_ID". 
SELECT
    Employee_ID AS "ID OF THE EMPLOYEE",
    Last_Name AS "NAME OF THE EMPLOYEE",
    EmpDepartment_ID AS "DEP_ID"
FROM Employee;

--7. LIST OUT THE EMPLOYEES ANNUAL SALARY WITH THEIR NAMES ONLY.
select CONCAT(First_Name,' ',Middle_Name,' ',Last_Name) as [Name],(Salary * 12) as [Annual Salary]
from Employee

------------------------------------------------------------------------------------------------


-------------------------------------WHERE CONDITION:-----------------------------

--1. List the details about "Smith".
SELECT *
FROM Employee
WHERE Last_Name = 'SMITH';

--2.LIST OUT THE EMPLOYEES WHO ARE WORKING IN DEPARTMENT 20.
SELECT *
FROM Employee
WHERE EmpDepartment_ID = 20;

--3.LIST OUT THE EMPLOYEES WHO ARE EARNING SALARY BETWEEN 3000 AND 4500.
SELECT *
FROM Employee
WHERE Salary BETWEEN 3000 AND 4500;

--4. LIST OUT THE EMPLOYEES WHO ARE WORKING IN DEPARTMENT 10 OR 20.
SELECT *
FROM Employee
WHERE EmpDepartment_ID IN (10, 20);

--5. Find out the employees who are not working in department 10 or 30
SELECT * FROM Employee WHERE EmpDepartment_ID NOT IN (10, 30);

--6. List out the employees whose name starts with 'S'.
SELECT * FROM Employee WHERE First_Name LIKE 'S%';

--7. List out the employees whose name starts with 'S' and ends with 'H'.
SELECT * FROM Employee WHERE First_Name LIKE 'S%h';

--8. List out the employees whose name length is 4 and start with 'S'.
SELECT * FROM Employee WHERE LEN(First_Name) = 4 AND First_Name LIKE 'S%';

--9. List out employees who are working in department 10 and draw salaries more than 3500.
SELECT * FROM Employee WHERE EmpDepartment_ID = 10 AND Salary > 3500;

--10. List out the employees who are not receiving commission.
SELECT * FROM Employee WHERE Comm IS NULL;

------------------------------------------------------------------------------------------------


---------------------------------ORDER BY Clause:--------------------------------

--1. List out the Employee ID and Last Name in ascending order based on the Employee ID.
SELECT Employee_ID, Last_Name FROM Employee ORDER BY Employee_ID ASC;

--2. List out the Employee ID and Name in descending order based on salary.
SELECT Employee_ID,CONCAT(First_Name, ' ',Middle_Name,' ',Last_Name) AS "Name"
FROM Employee
ORDER BY Salary DESC;

--3. List out the employee details according to their Last Name in ascending-order.
SELECT * FROM Employee ORDER BY Last_Name ASC;

--4. List out the employee details according to their Last Name in ascending order 
--   and then Department ID in descending order.
SELECT * FROM Employee ORDER BY Last_Name ASC, EmpDepartment_ID DESC;

------------------------------------------------------------------------------------------------


---------------------------------GROUP BY AND HAVING Clause:--------------------------------

--1. How many employees are in different departments in the organization?
SELECT EmpDepartment_ID, COUNT(*) AS "Number of Employees"
FROM Employee
GROUP BY EmpDepartment_ID;

--2. List out the department wise maximum salary, minimum salary and average salary of the employees.
SELECT
    EmpDepartment_ID,
    MAX(Salary) AS "Max Salary",
    MIN(Salary) AS "Min Salary",
    AVG(Salary) AS "Avg Salary"
FROM Employee
GROUP BY EmpDepartment_ID;

--3. List out the job wise maximum salary, minimum salary and average salary of the employees.
SELECT
    EmpJob_ID,
    MAX(Salary) AS "Max Salary",
    MIN(Salary) AS "Min Salary",
    AVG(Salary) AS "Avg Salary"
FROM Employee
GROUP BY EmpJob_ID;

--4. List out the number of employees who joined each month in ascendingorder.
SELECT MONTH(Hire_Date) AS "Join Month", COUNT(*) AS "Number of Employees"
FROM Employee
GROUP BY MONTH(Hire_Date)
ORDER BY MONTH(Hire_Date) ASC;

--5. List out the number of employees for each month and year in 
--   ascending order based on the year and month.
SELECT 
    YEAR(Hire_Date) AS "Join Year",
    MONTH(Hire_Date) AS "Join Month",
    COUNT(*) AS "Number of Employees"
FROM Employee
GROUP BY YEAR(Hire_Date), MONTH(Hire_Date)
ORDER BY YEAR(Hire_Date) ASC, MONTH(Hire_Date) ASC;

--6. List out the Department ID having at least four employees.
SELECT EmpDepartment_ID, COUNT(*) AS "Number of Employees"
FROM Employee
GROUP BY EmpDepartment_ID
HAVING COUNT(*) >= 4;

--7. How many employees joined in the month of January?
SELECT COUNT(*) AS "EMPLOYEE_JOIN_IN_JANUARY"
FROM Employee
WHERE MONTH(Hire_Date) = 1;

--8. How many employees joined in the month of January or September?
SELECT COUNT(*) AS "NO_OF_Employees_JOIN_IN_JAN_OR_SEPT"
FROM Employee
WHERE MONTH(Hire_Date) IN (1, 9);

--9. How many employees joined in 1985?
SELECT COUNT(*) AS "EMPLOYEES_JOIN_IN_1985"
FROM Employee
WHERE YEAR(Hire_Date) = 1985;

--10. How many employees joined each month in 1985?
SELECT MONTH(Hire_Date) AS "Join Month", COUNT(*) AS "Number of Employees"
FROM Employee
WHERE YEAR(Hire_Date) = 1985
GROUP BY MONTH(Hire_Date)
ORDER BY MONTH(Hire_Date) ASC;

--11. How many employees joined in March 1985?
SELECT COUNT(*) AS "Number of Employees"
FROM Employee
WHERE MONTH(Hire_Date) = 3 AND YEAR(Hire_Date) = 1985;

--12. Which is the Department ID having greater than or equal to 3 employees joining in April 1985?
SELECT EmpDepartment_ID, COUNT(*) AS "Number of Employees"
FROM Employee
WHERE MONTH(Hire_Date) = 4 AND YEAR(Hire_Date) = 1985
GROUP BY EmpDepartment_ID
HAVING COUNT(*) >= 3;

------------------------------------------------------------------------------------------------


---------------------------------JOINS:--------------------------------

--1. List out employees with their department names.
SELECT E.Employee_ID, 
CONCAT (E.First_Name,'   ', E.Last_Name)AS EMPLOYEE_NAME,
D.DeptName
FROM Employee E
INNER JOIN 
Department D ON E.EmpDepartment_ID = D.Department_ID;

--2. Display employees with their designations.
SELECT E.Employee_ID, 
CONCAT (E.First_Name,'   ', E.Last_Name)AS EMPLOYEE_NAME,
J.Designation
FROM Employee E
INNER JOIN Job J ON E.EmpJob_ID = J.Job_ID;

--3. Display the employees with their department names and regional groups.
SELECT E.Employee_ID, 
CONCAT (E.First_Name,'   ', E.Last_Name)AS EMPLOYEE_NAME,
D.DeptName, L.City
FROM Employee E
INNER JOIN Department D ON E.EmpDepartment_ID = D.Department_ID
INNER JOIN Location L ON D.DepLocation_ID = L.Location_ID;

--4. How many employees are working in different departments? Display with department names.
SELECT D.Department_ID, D.DeptName, COUNT(*) AS "Number of Employees"
FROM Employee E
INNER JOIN Department D ON E.EmpDepartment_ID = D.Department_ID
GROUP BY D.Department_ID, D.DeptName;

--5. How many employees are working in the sales department?
SELECT COUNT(*) AS "Number of Employees"
FROM Employee E
INNER JOIN Department D ON E.EmpDepartment_ID = D.Department_ID
WHERE D.DeptName = 'Sales';

--6. Which is the department having greater than or equal to 5 employees?
--   Display the department names in ascending order.
SELECT D.Department_ID, D.DeptName, COUNT(*) AS "Number of Employees"
FROM Employee E
INNER JOIN Department D ON E.EmpDepartment_ID = D.Department_ID
GROUP BY D.Department_ID, D.DeptName
HAVING COUNT(*) >= 5
ORDER BY D.DeptName ASC;

--7. How many jobs are there in the organization? Display with designations.
SELECT COUNT(*) AS "Number of Jobs", Designation
FROM Job
GROUP BY Designation;

--8. How many employees are working in "New York"?
SELECT COUNT(*) AS "Number of Employees"
FROM Employee E
INNER JOIN Department D ON E.EmpDepartment_ID = D.Department_ID
INNER JOIN Location L ON D.DepLocation_ID = L.Location_ID
WHERE L.City = 'New York';

--9. Display the employee details with salary grades.
--   Use conditional statement to create a grade column.
SELECT
	EMPLOYEE_ID,
	FIRST_NAME,
	LAST_NAME,
	SALARY,
		CASE
			WHEN SALARY >= 5000 THEN 'Grade A'
			WHEN SALARY >= 4000 THEN 'Grade B'
			WHEN SALARY >= 3000 THEN 'Grade C'
			ELSE 'Grade D'
			END AS SalaryGrade
FROM EMPLOYEE;

--10. List out the number of employees grade wise. 
--    Use conditional statement to create a grade column.
SELECT 
    CASE 
        WHEN Salary >= 5000 THEN 'A'
        WHEN Salary >= 3000 THEN 'B'
        ELSE 'C'
    END AS "Salary Grade",
    COUNT(*) AS "Number of Employees"
FROM Employee
GROUP BY 
    CASE 
        WHEN Salary >= 5000 THEN 'A'
        WHEN Salary >= 3000 THEN 'B'
        ELSE 'C'
    END;

--11. Display the employee salary grades and the number of employees 
--    between 2000 to 5000 range of salary
SELECT 
    CASE 
        WHEN Salary >= 5000 THEN 'A'
        WHEN Salary >= 3000 THEN 'B'
        ELSE 'C'
    END AS "Salary Grade",
    COUNT(*) AS "Number of Employees"
FROM Employee
WHERE Salary BETWEEN 2000 AND 5000
GROUP BY 
    CASE 
        WHEN Salary >= 5000 THEN 'A'
        WHEN Salary >= 3000 THEN 'B'
        ELSE 'C'
    END;

--12. Display all employees in sales or operation departments.
SELECT E.Employee_ID, E.First_Name, E.Last_Name, D.DeptName
FROM Employee E
INNER JOIN Department D ON E.EmpDepartment_ID = D.Department_ID
WHERE D.DeptName IN ('Sales', 'Operations');

------------------------------------------------------------------------------------------------


---------------------------------SET OPERATORS:--------------------------------

--1. List out the distinct jobs in sales and accounting departments.
SELECT DISTINCT J.DESIGNATION
FROM EMPLOYEE E
INNER JOIN JOB J ON E.EmpJob_ID = J.JOB_ID
INNER JOIN DEPARTMENT D ON E.EmpDepartment_ID = D.DEPARTMENT_ID
WHERE D.DeptName IN ('Sales', 'Accounting');

--2. List out all the jobs in sales and accounting departments.
SELECT J.DESIGNATION
FROM EMPLOYEE E
INNER JOIN JOB J ON E.EmpJob_ID = J.JOB_ID
INNER JOIN DEPARTMENT D ON E.EmpDepartment_ID = D.DEPARTMENT_ID
WHERE D.DeptName IN ('Sales', 'Accounting');

--3. List out the common jobs in research and accounting departments in ascending order.
SELECT J.DESIGNATION
FROM EMPLOYEE E
INNER JOIN JOB J ON E.EmpJob_ID = J.JOB_ID
INNER JOIN DEPARTMENT D ON E.EmpDepartment_ID = D.DEPARTMENT_ID
WHERE D.DeptName IN ('Research', 'Accounting')
GROUP BY J.DESIGNATION
HAVING COUNT(DISTINCT D.DeptName) = 2
ORDER BY J.DESIGNATION ASC;

------------------------------------------------------------------------------------------------


---------------------------------SUB QUERIES:--------------------------------

--1. Display the employees list who got the maximum salary.
SELECT *
FROM Employee
WHERE Salary = (SELECT MAX(Salary) FROM Employee);

--2. Display the employees who are working in the sales department.
SELECT *
FROM Employee
WHERE EmpDepartment_ID = (SELECT Department_ID FROM Department WHERE DeptName = 'Sales');

--3. Display the employees who are working as 'Clerk'.
SELECT *
FROM Employee
WHERE EmpJob_ID = (SELECT Job_ID FROM Job WHERE Designation = 'Clerk');

--4. Display the list of employees who are living in "New York".
SELECT *
FROM Employee
WHERE EmpDepartment_ID 
IN 
(SELECT Department_ID FROM Department 
  WHERE 
     DepLocation_ID = (SELECT Location_ID FROM Location WHERE City = 'New York'));

--5. Find out the number of employees working in the sales department.
SELECT COUNT(*) AS "Number of Employees"
FROM Employee
WHERE EmpDepartment_ID = (SELECT Department_ID FROM Department WHERE DeptName = 'Sales');

--6. Update the salaries of employees who are working as clerks on the basis of 10%.
UPDATE Employee
SET Salary = Salary * 1.10
WHERE EmpJob_ID = (SELECT Job_ID FROM Job WHERE Designation = 'Clerk');

--7. Delete the employees who are working in the accounting department.
DELETE FROM Employee
WHERE EmpDepartment_ID = (SELECT Department_ID FROM Department WHERE DeptName = 'Accounting');

--8. Display the second highest salary drawing employee details.
SELECT *
FROM Employee
WHERE Salary = (SELECT MAX(Salary) FROM Employee WHERE Salary < (SELECT MAX(Salary) FROM Employee));

--9. Display the nth highest salary drawing employee details.
SELECT *
FROM (
    SELECT 
        Employee.*, 
        ROW_NUMBER() OVER (ORDER BY Salary DESC) AS RowNum
    FROM Employee
) AS RankedEmployees
WHERE RowNum = 2;

--10. List out the employees who earn more than every employee in department 30.
SELECT *
FROM Employee
WHERE Salary > ALL (SELECT Salary FROM Employee WHERE EmpDepartment_ID = 30);

--11.List out the employees who earn more than the lowest salary in
--department.Find out whose department has no employees?

--List out the employees who earn more than the lowest salary in department.
SELECT * FROM Employee
WHERE Salary > (SELECT MIN(Salary) FROM Employee 
WHERE EmpDepartment_ID = Employee.EmpDepartment_ID);

--Find out whose department has no employees?
SELECT * FROM Department d 
LEFT JOIN Employee e ON d.Department_ID = e.EmpDepartment_ID
WHERE e.EmpDepartment_ID IS NULL;
--Answer: Accounting department has no employee

--12. Find out which department has no employees.
SELECT Department_ID, DeptName
FROM Department
WHERE Department_ID NOT IN (SELECT DISTINCT EmpDepartment_ID FROM Employee);

--13.Find out the employees who earn greater than the average salary for their department.
SELECT *
FROM Employee
WHERE Salary > (SELECT AVG(Salary) FROM Employee WHERE EmpDepartment_ID = Employee.EmpDepartment_ID);



